﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace itelec4.Api_Models
{
    public class MstCourse_ApiModel
    {
        public Int32 Id { get; set; }
        public String CourseCode { get; set; }
        public String Course { get; set; }
    }
}