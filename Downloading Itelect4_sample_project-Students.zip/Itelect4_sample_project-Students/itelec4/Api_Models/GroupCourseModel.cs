﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace itelec4.Api_Models
{
    public class GroupCourseModel
    {
        public String Course { get; set; }
        public Int32 Total { get; set; }
    }
}