﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace itelec4.Api_Models
{
    public class HealthWorkerModel
    {
        public Int32 Id { get; set; }
        public String HealthWorkerCode { get; set; }
        public String FullName { get; set; }
    }
}